import tkinter as tk
import threading
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from wonderwords import RandomWord
import time
import json

driver = webdriver.Edge()
driver.get('https://www.bing.com/search?q=initiating&FORM=AWRE')

prev_point = driver.find_element(By.ID, 'id_rc').text

if(prev_point == "Rewards"):
    prev_point = "Searching for Points"
else:
    prev_point = driver.find_element(By.ID, 'id_rc').text


def random_letter():
    word = RandomWord().word()
    return "what does " + word + " mean?"

def run_bot():
    global count, stop_flag, added
    count = 0
    added = 0
    stop_flag = False
    wait_time = float(time_entry.get())
    while not stop_flag:
        search_box = driver.find_element("id", 'sb_form_q')
        search_box.click()
        search_box.send_keys(Keys.CONTROL + 'a')
        search_box.send_keys(Keys.BACKSPACE)
        search_box.send_keys(random_letter())
        search_box.send_keys(Keys.RETURN)
        count += 1
        added += 3
        update_count_label()
        update_added_points()
        update_points()
        time.sleep(wait_time)

def stop_bot():
    global stop_flag

    x = {
        
    }

    stop_flag = True

def update_count_label():
    count_label.config(text="Count: {}".format(count))

def update_points():
    current_points = driver.find_element(By.ID, 'id_rc').text
    if(current_points == "Rewards"):
        points_label.config(text="Point(s): Searching for Points")
    else:
        points_label.config(text="Point(s): {}".format(current_points))

def update_added_points():
    added_label.config(text="Should Increment by: {}".format(added))

root = tk.Tk()
root.title("Bot Control Panel")
root.geometry("300x160")
root.iconbitmap('../icon.ico')

count_label = tk.Label(root, text="Count: 0")
count_label.pack()

points_label = tk.Label(root, text="Point(s): {}".format(prev_point))
points_label.pack()

added_label = tk.Label(root, text="Should Increment by: 0")
added_label.pack()

time_entry_label = tk.Label(root, text="Wait time (seconds):")
time_entry_label.pack()
time_entry = tk.Entry(root)
time_entry.pack()
time_entry.insert(0, "4.5")

bot_button = tk.Button(root, text="Start Bot", command=lambda: threading.Thread(target=run_bot).start())
bot_button.pack()

stop_button = tk.Button(root, text="Stop Bot", command=stop_bot)
stop_button.pack()

root.mainloop()