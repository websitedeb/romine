How to Use this Bot

first go to the bin folder, then you clikc on the bot.exe, and your done!

you can make a short cut for this if you want

when you want to stop the bot, close the browser and control panel

this could be ran over night, but microsoft rewards has a limit from 200-500 point per day

and also, there will be an error that shows in the terminal when the bot runs -

" [30744:22396:0331/132703.149:ERROR:fallback_task_provider.cc(126)] Every renderer should have at least one task provided by a primary task provider. If a "Renderer" fallback task is shown, it is a bug. If you have repro steps, please file a new bug and tag it as a dependency of crbug.com/739782. "

ignore this error, it dosnt affect the process of the code.

!!! MAKE SURE TO USE EDGE BROWSER AND HAVE A MICROSOFT ACCOUNT !!!

-----------Romine------------