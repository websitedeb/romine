How to Use this Bot

first make sure you got the following installed -

* python
* pip
* npm

by writing in the command prompt

" python --version "
" pip --version "
" npm --version "

if an error pops up, you must download it and make it a env variable in your system

then in the terminal write these

" pip install selenium "
" pip install wonderwords "
" pip install tkinter "
" pip install threading "

to start the bot write this in the terminal

" npm start "

when you want to stop the bot, close the browser and control panel

this could be ran over night, but microsoft rewards has a limit from 200-500 point per day

and also, there will be an error that shows in the terminal when the bot runs -

" [30744:22396:0331/132703.149:ERROR:fallback_task_provider.cc(126)] Every renderer should have at least one task provided by a primary task provider. If a "Renderer" fallback task is shown, it is a bug. If you have repro steps, please file a new bug and tag it as a dependency of crbug.com/739782. "

ignore this error, it dosnt affect the process of the code.

!!! MAKE SURE TO USE EDGE BROWSER AND HAVE A MICROSOFT ACCOUNT !!!

---made by Sarthak Ghoshal---
-----------RoMine------------